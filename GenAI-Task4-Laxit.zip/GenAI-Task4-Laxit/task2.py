# Task 2: 

# 1
with open("sales_data.txt", "r") as file:
    print("1. Entire file:")
    print(file.read())

# 2
with open("sales_data.txt", "r") as file:
    print("2. First line:")
    print(file.readline().strip())

# 3
with open("sales_data.txt", "r") as file:
    lines = file.readlines()

sales = []
for line in lines:
    sales.append(int(line.strip()))

print("3. Sales as integers:")
print(sales)
