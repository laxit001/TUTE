# Task 7

prices = {
    "Mouse": 500,
    "Keyboard": 800,
    "Monitor": 7000,
    "Pendrive": 400,
    "Camera": 5000
}

discount = float(input("Enter discount percentage: "))

total_discounted_price = 0

with open("discount_report.txt", "w") as file:
    file.write("Product | Original Price | Discounted Price\n")

    for product, price in prices.items():
        discounted_price = price - (price * discount / 100)
        total_discounted_price += discounted_price

        file.write(
            product + " | " +
            str(price) + " | " +
            str(round(discounted_price, 2)) + "\n"
        )

average_discounted_price = total_discounted_price / len(prices)

# Optional summary
with open("discount_report.txt", "a") as file:
    file.write("\nTotal Items: " + str(len(prices)) + "\n")
    file.write(
        "Average Discounted Price: " +
        str(round(average_discounted_price, 2)) + "\n"
    )

with open("discount_report.txt", "r") as file:
    print("\nDiscount Report:")
    print(file.read())
