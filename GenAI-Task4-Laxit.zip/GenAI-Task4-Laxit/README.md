## How to Run

Run the tasks separately from the folder.

Example:

```text
python task1.py
python task2.py
python task3.py
python task4.py
python task5.py
python task6.py
python task7.py
```

### Important

Run `task1.py` before `task2.py`, `task3.py`, and `task4.py` because they use `sales_data.txt`.

`task5.py` creates `products.txt`.

`task7.py` creates `discount_report.txt`.

