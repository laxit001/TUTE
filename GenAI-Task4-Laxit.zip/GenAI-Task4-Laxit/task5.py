# Task 5

with open("products.txt", "w") as file:
    for i in range(3):
        product_name = input("Enter product name: ")
        price = input("Enter product price: ")
        file.write(product_name + " | " + price + "\n")

with open("products.txt", "r") as file:
    lines = file.readlines()

print("\nProduct Information:")
for line in lines:
    parts = line.strip().split(" | ")
    print("Product Name:", parts[0])
    print("Price:", parts[1])
    print()
