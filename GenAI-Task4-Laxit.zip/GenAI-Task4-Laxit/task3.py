# Task 3

new_sales = [5000, 2500, 1700]

with open("sales_data.txt", "a") as file:
    for sale in new_sales:
        file.write(str(sale) + "\n")

with open("sales_data.txt", "r") as file:
    updated_data = file.read()

print("Updated Sales Data:")
print(updated_data)

# Optional
with open("sales_data.txt", "r") as file:
    lines = file.readlines()

print("Total number of lines:", len(lines))
