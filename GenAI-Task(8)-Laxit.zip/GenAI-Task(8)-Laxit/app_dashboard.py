import streamlit as st

st.title("Simple Sales Dashboard")
st.write("This is a simple dashboard")

months=["January","February","March","April"]
sales ={
    "January":1200,
    "February": 1300,
    "March":1250,
    "April":1700
}

month = st.selectbox("Select a month",months)

st.metric("Sales",sales[month])

st.bar_chart(list(sales.values()))