import streamlit as st

product=st.sidebar.text_input("Enter product name ")
cat=st.sidebar.selectbox(
    "Category",
    ["Electronics", "Accessories", "Furniture", "Clothing"]
)
price=st.sidebar.number_input("enter the price of product")

if st.sidebar.button("ADD product"):
    st.success("Product added")

    table=[[product],[cat],[price]]

    st.table(table)