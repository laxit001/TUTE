import streamlit as st 

st.title("Welcome to Streamlit!")
name=st.text_input("Enter your name")
but=st.button("Greet Me")
if but:
    st.write("Hello,!",name)

