import streamlit as st 

price =st.number_input("enter the price")

dis=st.slider("Discount percentage",0,50,0)

but=st.button("Calculate")
if but:
    finall_price= price - (price*dis/100)
    st.success(finall_price)

    table=[["before",price],["after",finall_price]]

    st.table(table)