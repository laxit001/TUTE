import ast
import json
import re

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


# Task 1: Load and understand
df = pd.read_csv("tmdb_5000_movies.csv")

print("Shape:", df.shape)
print("\nColumns:")
print(df.columns.tolist())
print("\nFirst 5 rows:")
print(df.head())
print("\nData types:")
print(df.dtypes)
print("\nMissing values:")
print(df[["title", "overview", "genres"]].isnull().sum())


# Convert JSON-like columns into readable text
def get_names(value):
    if not value:
        return ""

    try:
        data = json.loads(value)
    except (json.JSONDecodeError, TypeError):
        try:
            data = ast.literal_eval(value)
        except (ValueError, SyntaxError):
            return str(value)

    if isinstance(data, list):
        return " ".join(
            str(item.get("name", ""))
            for item in data
            if isinstance(item, dict)
        )

    return str(data)


# Task 2: Text preprocessing
for column in ["overview", "genres", "keywords", "tagline"]:
    df[column] = df[column].fillna("")

df["genre_text"] = df["genres"].apply(get_names)
df["keyword_text"] = df["keywords"].apply(get_names)


def clean_text(text):
    text = str(text).lower()
    text = re.sub(r"http\S+|www\S+", " ", text)
    text = re.sub(r"[^a-z\s]", " ", text)

    stop_words = {
        "the", "a", "an", "and", "or", "of", "to", "in", "for",
        "on", "is", "with", "from", "into", "its", "that", "this",
        "who", "while", "as", "at", "by", "be", "are", "was", "were"
    }

    return " ".join(
        word for word in text.split()
        if word not in stop_words
    )


df["clean_text"] = (
    df["overview"] + " " +
    df["genre_text"] + " " +
    df["keyword_text"] + " " +
    df["tagline"]
).apply(clean_text)

print("\nClean text example:")
print(df[["title", "clean_text"]].head())


# Task 3: TF-IDF
vectorizer = TfidfVectorizer(
    max_features=10000,
    ngram_range=(1, 2)
)

tfidf_matrix = vectorizer.fit_transform(df["clean_text"])
print("\nTF-IDF matrix shape:", tfidf_matrix.shape)


# Task 4: Cosine similarity
similarity_matrix = cosine_similarity(
    tfidf_matrix, dense_output=True
).astype("float32")

print("Similarity matrix shape:", similarity_matrix.shape)


# Task 5: Recommendation function
def recommend(item_name, top_n=5):
    matches = df.index[
        df["title"].str.lower() == item_name.lower()
    ].tolist()

    if not matches:
        return pd.DataFrame()

    item_index = matches[0]
    scores = list(enumerate(similarity_matrix[item_index]))
    scores = sorted(scores, key=lambda x: x[1], reverse=True)

    recommendations = []

    for index, score in scores:
        if index == item_index:
            continue

        recommendations.append({
            "title": df.iloc[index]["title"],
            "genres": df.iloc[index]["genre_text"],
            "similarity": round(float(score), 3)
        })

        if len(recommendations) == top_n:
            break

    return pd.DataFrame(recommendations)


for movie in ["Avatar", "Titanic", "The Dark Knight"]:
    print("\nRecommendations for:", movie)
    print(recommend(movie, 5))

# Task 6 is implemented in app.py.
# Tasks 7-9 instructions are in README.md.
