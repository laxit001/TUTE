# GenAI Task 20 - Building & Deploying a Recommendation System

## Project

This is a simple content-based movie recommendation system.

It uses movie overview, genres, keywords and tagline as text features.

Flow:

Raw data -> text cleaning -> TF-IDF -> cosine similarity -> recommendations -> Streamlit

## Dataset

Dataset: **TMDB 5000 Movie Dataset**

Kaggle:
https://www.kaggle.com/datasets/tmdb/tmdb-movie-metadata

The uploaded CSV is used directly in this assignment.

Dataset:
- 4803 rows
- 20 columns

Important columns:
- `title`
- `overview`
- `genres`
- `keywords`
- `tagline`

## Tasks Covered

### Task 1 - Load and Understand
The code prints shape, columns, first 5 rows, data types and missing values.

### Task 2 - Text Preprocessing
Text is converted to lowercase. URLs, punctuation, special characters and simple stopwords are removed.

The JSON-like genres and keywords are converted into normal text.

The final text is stored in `clean_text`.

### Task 3 - TF-IDF
`TfidfVectorizer` is used with:

```text
max_features=10000
ngram_range=(1, 2)
```

### Task 4 - Cosine Similarity
Cosine similarity is calculated between all movie vectors and stored in `similarity_matrix`.

Cosine similarity is useful because it measures how similar the text vectors are.

### Task 5 - Recommendation Function
The function is:

```text
recommend(item_name, top_n=5)
```

It finds the selected movie, sorts the similarity scores and returns the most similar movies.

Three test movies are included:
- Avatar
- Titanic
- The Dark Knight

### Task 6 - Streamlit UI
The Streamlit app has:
- movie dropdown
- number of recommendations slider
- recommendation button
- movie details and similarity score

Run:

```text
streamlit run app.py
```

### Task 7 - GitHub

Create a GitHub repository and run:

```text
git init
git add .
git commit -m "Movie recommendation system"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

### Task 8 - Render

Connect the GitHub repository to Render.

Build command:

```text
pip install -r requirements.txt
```

Start command:

```text
streamlit run app.py --server.port $PORT --server.address 0.0.0.0
```

### Task 9 - Final Validation

After deployment:
1. Open the Render URL.
2. Select a movie.
3. Click Recommend Movies.
4. Check the recommendations.
5. Put the deployed URL in the final submission.

## Files

- `app.py` - Streamlit application
- `assignment20.py` - assignment tasks and tests
- `tmdb_5000_movies.csv` - uploaded full dataset
- `requirements.txt` - required libraries
- `README.md` - project explanation

## Installation

```text
pip install -r requirements.txt
```

## Run

```text
streamlit run app.py
```

## Libraries

- Python
- pandas
- scikit-learn
- Streamlit
