import ast
import json
import re

import pandas as pd
import streamlit as st
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


st.set_page_config(page_title="Movie Recommendation System", page_icon="🎬")


@st.cache_data
def load_data():
    df = pd.read_csv("tmdb_5000_movies.csv")

    print("Dataset shape:", df.shape)
    print("Columns:", list(df.columns))
    print(df.head())

    for column in ["overview", "genres", "keywords", "tagline"]:
        df[column] = df[column].fillna("")

    return df


def get_names(value):
    if not value:
        return ""

    try:
        data = json.loads(value)
    except (json.JSONDecodeError, TypeError):
        try:
            data = ast.literal_eval(value)
        except (ValueError, SyntaxError):
            return str(value)

    if isinstance(data, list):
        return " ".join(
            str(item.get("name", ""))
            for item in data
            if isinstance(item, dict)
        )

    return str(data)


def clean_text(text):
    text = str(text).lower()
    text = re.sub(r"http\S+|www\S+", " ", text)
    text = re.sub(r"[^a-z\s]", " ", text)

    stop_words = {
        "the", "a", "an", "and", "or", "of", "to", "in", "for",
        "on", "is", "with", "from", "into", "its", "that", "this",
        "who", "while", "as", "at", "by", "be", "are", "was", "were"
    }

    words = [word for word in text.split() if word not in stop_words]
    return " ".join(words)


@st.cache_resource
def build_model(df):
    df["genre_text"] = df["genres"].apply(get_names)
    df["keyword_text"] = df["keywords"].apply(get_names)

    df["clean_text"] = (
        df["overview"] + " " +
        df["genre_text"] + " " +
        df["keyword_text"] + " " +
        df["tagline"]
    ).apply(clean_text)

    vectorizer = TfidfVectorizer(
        max_features=10000,
        ngram_range=(1, 2)
    )

    tfidf_matrix = vectorizer.fit_transform(df["clean_text"])

    print("TF-IDF matrix shape:", tfidf_matrix.shape)

    similarity_matrix = cosine_similarity(
        tfidf_matrix, dense_output=True
    ).astype("float32")

    return df, vectorizer, tfidf_matrix, similarity_matrix


def recommend(item_name, df, similarity_matrix, top_n=5):
    matches = df.index[
        df["title"].str.lower() == item_name.lower()
    ].tolist()

    if not matches:
        return pd.DataFrame(
            columns=["title", "genres", "overview", "similarity"]
        )

    item_index = matches[0]

    scores = list(enumerate(similarity_matrix[item_index]))
    scores = sorted(scores, key=lambda x: x[1], reverse=True)

    results = []

    for index, score in scores:
        if index == item_index:
            continue

        results.append({
            "title": df.iloc[index]["title"],
            "genres": df.iloc[index]["genre_text"],
            "overview": df.iloc[index]["overview"],
            "similarity": round(float(score), 3)
        })

        if len(results) == top_n:
            break

    return pd.DataFrame(results)


df = load_data()
df, vectorizer, tfidf_matrix, similarity_matrix = build_model(df)

print("Final TF-IDF matrix:", tfidf_matrix.shape)
print("Similarity matrix:", similarity_matrix.shape)

for movie in ["Avatar", "Titanic", "The Dark Knight"]:
    test_result = recommend(movie, df, similarity_matrix, 5)
    print("\nTest:", movie)
    print(test_result[["title", "similarity"]])


st.title("🎬 Movie Recommendation System")
st.write("Content-based recommendations using movie text information.")

selected_movie = st.selectbox(
    "Choose a movie",
    df["title"].tolist()
)

top_n = st.slider(
    "Number of recommendations",
    min_value=1,
    max_value=10,
    value=5
)

if st.button("Recommend Movies"):
    results = recommend(
        selected_movie,
        df,
        similarity_matrix,
        top_n
    )

    st.subheader("Recommended Movies")

    for _, row in results.iterrows():
        st.write("###", row["title"])
        st.write("**Genres:**", row["genres"])
        st.write(row["overview"])
        st.write("**Similarity:**", row["similarity"])
        st.divider()
