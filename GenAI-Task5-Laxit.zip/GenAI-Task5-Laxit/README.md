# Assignment 5

This assignment is about Python modules and packages.

Files:
- main.py
- math_utils.py
- string_utils.py
- shop_package

Run:
python main.py

The main file tests the functions from the modules and package.
