import math_utils
from math_utils import square
import string_utils

import shop_package
import shop_package.discount as disc
from shop_package.billing import calculate_total

print("Math functions:")
print(math_utils.add(10, 5))
print(math_utils.subtract(10, 5))
print(square(5))

print("\nString functions:")
print(string_utils.capitalize_words("hello python world"))
print(string_utils.reverse_string("python"))
print(string_utils.word_count("Python is easy to learn"))

print("\nShop package:")
print(disc.apply_discount(1000, 10))
print(disc.flat_discount(500))
print(calculate_total([100, 200, 300]))
print(shop_package.apply_tax(1000))
