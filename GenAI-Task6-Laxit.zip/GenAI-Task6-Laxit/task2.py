# Task 2: Bill Calculator

prices = [120, 350, "abc", 500, -200, 800]
total = 0

for price in prices:
    try:
        if not isinstance(price, (int, float)):
            raise TypeError("Price is not a number")

        if price <= 0:
            raise ValueError("Negative price not allowed")

        total += price

    except TypeError as e:
        print(e)
    except ValueError as e:
        print(e)

print("Running total:", total)
