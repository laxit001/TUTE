# Assignment 6

This assignment is about exception handling in Python.

Files:
- task1.py - Safe division
- task2.py - Bill calculator
- task3.py - Age validator
- task4.py - File reader
- task5.py - Shopping cart

Run any task with:

python task1.py

The programs use try, except, else, finally, raise and common Python exceptions.
