# Task 4: File Reader

filename = input("Enter a filename: ")

try:
    with open(filename, "r") as file:
        lines = file.readlines()

    print("First 3 lines:")
    for line in lines[:3]:
        print(line.strip())

except FileNotFoundError:
    print("File not found.")
except PermissionError:
    print("Permission denied.")
finally:
    print("File operation attempted.")
